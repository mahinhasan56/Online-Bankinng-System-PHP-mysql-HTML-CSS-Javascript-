<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Contact Us</title>
        
        <link rel="stylesheet" href="CSS/style.css">
        <style>
            .heading{
    font-weight:bold;
    color:#2E4372;
}
        </style>
       
    </head>
        <?php include 'header.php' ?>
        <div class='content_customer'>
            <h3 style="text-align:center;color:#2E4372;"><u>Contact Us</u></h3>
            
            <div class="contact">
            <h3 style="color:#2E4372;"><u>Motijheel Branch</u></h3>
            <p><span class="heading">Address - </span>32/1 Dilcusha C/A Motijheel,Dhaka</p>
            <p><span class="heading">Tel - </span>880-0123328</p>
            <p><span class="heading">Email - </span>dilcusha@onlinebank.com</p>
            
             <h3 style="color:#2E4372;"><u>Dhanmondi Branch</u></h3>
            <p><span class="heading">Address - </span>81, road number, 7a dhanmondi dhaka,1202</p>
            <p><span class="heading">Tel - </span>880-0123328</p>
            <p><span class="heading">Email - </span>jigatola@onlinebank.com</p>
            
             <h3 style="color:#2E4372;"><u>Mohakhali Branch</u></h3>
            <p><span class="heading">Address - </span>Mohakhali,beside brac university</p>
            <p><span class="heading">Tel - </span>880-01233281</p>
            <p><span class="heading">Email - </span>mohakhali@onlinebank.com</p>
            </div>
            </div>