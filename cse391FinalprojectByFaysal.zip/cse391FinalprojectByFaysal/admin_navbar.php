<div class='admin_nav'>
               <ul>
                   <li id='caption'><b><u>Admin</u></b></li>
                   
                   <li><a href="admin_dashboard.php">Admin Home</a></li><br/><br/>
                   <li><a href="admin_logout.php">Logout</a></li>

                   </ul>
               </div>