<div class='customer_nav'>
<ul>
<li id='caption'><b><u>Accounts</u><b></li>
 <li><a href="customer_account_summary.php">Customer Summary</a></li>
 <li><a href="balancehistory.php">Balance History</a></li>
</ul>

<ul>
    <li id='caption'><b><u>Fund Transfer</u></b></li>
    <li><a href="add_receiver_account.php">Add account recever</a></li>
    <li><a href="display_receiver.php">View added receiver</a></li>
    <li><a href="customer_money_transfer.php">Transfer Funds</a></li>
  
</ul>
<ul>
    <li id='caption'><b><u>Profile</u></b></li>
    <li><a href="logout.php">Logout</a></li>
</ul>
</div>