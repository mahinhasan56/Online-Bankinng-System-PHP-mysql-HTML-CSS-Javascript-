<!DOCTYPE html>
<html>
<title>Goals</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<body>

<div class="w3-container w3-center w3-animate-opacity">
  <h1>CSE 391</h1>
  <p>A Symbol Of Trust</p>
  <img src="image/b2.jpeg" alt="Easy Money Transfer" style="width:100%">
</div>

</body>
</html> 
