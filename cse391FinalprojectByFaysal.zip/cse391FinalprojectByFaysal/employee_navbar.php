<div class='customer_nav'>
               <ul>
                   <li id='caption'><b><u>Staff</u></b></li>
                   <li><a href="employee_dashboard.php">Staff Home</a></li>
                   <li><a href="employee_view_request.php">Approve Account Transfer Requests</a></li>
                 </ul>
                <br/><br/>
   <ul>
        <li id='caption'><b><u>Profile</u></b></li>
        <li><a href="employee_logout.php">Logout</a></li>
                    </ul>
    </div>
